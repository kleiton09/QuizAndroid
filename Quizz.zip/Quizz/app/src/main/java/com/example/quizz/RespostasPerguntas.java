package com.example.quizz;

public class RespostasPerguntas {

    public static String perguntas[] ={
        "Qual empresa é dona do android?",
        "Qual desses não é uma linguagem de programação?",
        "Qual desses é uma plataforma de streaming?"

    };

    public static String escolhas[][] = {
            {"Google", "Apple", "Nokia", "Samsung", "Xiaomi"},
            {"Java", "Kotlin", "Notepad", "Python", "C++"},
            {"Netflix", "Excel", "Clash of Clans", "Vscode", "Steam"}
    };

    public static String RespostasCorretas[] = {
    "Google",
    "Notepad",
    "Netflix"
    };
}
