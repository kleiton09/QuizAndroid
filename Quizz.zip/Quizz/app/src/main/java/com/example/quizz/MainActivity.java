package com.example.quizz;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView totalPerguntasTextView;
    TextView questoesTextview;
    Button respA,respB,respC,respD,respE;
    Button confirmarBtn;

    int pontuacao=0;
    int totalPerguntas= RespostasPerguntas.perguntas.length;
    int currentperguntaIndex= 0;
    String selectedResposta= "";




    @Override
    protected void onCreate(Bundle savedInstaceState) {

        super.onCreate(savedInstaceState);
        setContentView(R.layout.activity_main);

        totalPerguntasTextView = findViewById(R.id.total_perguntas);
        questoesTextview = findViewById(R.id.questoes);
        respA = findViewById(R.id.resposta_A);
        respB = findViewById(R.id.resposta_B);
        respC = findViewById(R.id.resposta_C);
        respD = findViewById(R.id.resposta_D);
        respE = findViewById(R.id.resposta_E);
        confirmarBtn = findViewById(R.id.confirmar);


        respA.setOnClickListener(this);
        respB.setOnClickListener(this);
        respC.setOnClickListener(this);
        respD.setOnClickListener(this);
        respE.setOnClickListener(this);
        confirmarBtn.setOnClickListener(this);


        totalPerguntasTextView.setText("Total Perguntas: "+totalPerguntas);


       carregarnovapergunta();





    }


    @Override
    public void onClick(View view) {

        respA.setBackgroundColor(Color.WHITE);
        respB.setBackgroundColor(Color.WHITE);
        respC.setBackgroundColor(Color.WHITE);
        respD.setBackgroundColor(Color.WHITE);
        respE.setBackgroundColor(Color.WHITE);


        Button clickedButton = (Button) view;
        if(clickedButton.getId()==R.id.confirmar){ if (selectedResposta.equals(RespostasPerguntas.RespostasCorretas[currentperguntaIndex])){
            pontuacao++;

        }
            currentperguntaIndex++;
            carregarnovapergunta();




        }else{
            //Botoes de escolhas clickados

            selectedResposta = clickedButton.getText().toString();
            clickedButton.setBackgroundColor(Color.MAGENTA);


        }

    }
        void carregarnovapergunta(){

        if (currentperguntaIndex == totalPerguntas){
            finishQuiz();
            return;
        }



            questoesTextview.setText(RespostasPerguntas.perguntas[currentperguntaIndex]);
            respA.setText(RespostasPerguntas.escolhas[currentperguntaIndex][0]);
            respB.setText(RespostasPerguntas.escolhas[currentperguntaIndex][1]);
            respC.setText(RespostasPerguntas.escolhas[currentperguntaIndex][2]);
            respD.setText(RespostasPerguntas.escolhas[currentperguntaIndex][3]);
            respE.setText(RespostasPerguntas.escolhas[currentperguntaIndex][4]);


        }

        void finishQuiz(){
            String passStatus = "";
            if (pontuacao > totalPerguntas*0.60){
                passStatus = "Passou";
            }else{
                passStatus = "Falhou";
            }

            new AlertDialog.Builder(this)
                    .setTitle(passStatus)
                    .setMessage("Pontução é " + pontuacao + "de" + totalPerguntas)
                    .setPositiveButton("Reiniciar",(dialogInterface, i) -> restartQuiz() )
                    .setCancelable(false)
                    .show();
        }
        void restartQuiz(){

        pontuacao = 0;
        currentperguntaIndex = 0;
        carregarnovapergunta();
}
}






